import React, { Component } from 'react';
import { View, KeyboardAvoidingView, TextInput, StyleSheet, Text, TouchableWithoutFeedback, Button, Keyboard, Alert  } from 'react-native';
const KeyboardAvoidingComponent = () => {
  return (
    <KeyboardAvoidingView>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.insidetext}>
          <Text style={styles.header}>Read A Story</Text>
          <TextInput placeholder="" style={styles.textInput} 
            here
          />
          <View style={styles.bottomContainer}>
            <Button title="Submit" onPress={() => alert('Thank you')} />
          </View>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};
const styles = StyleSheet.create({
  insidetext: {
    padding: 24,
    flex: 1,
    justifyContent: "space-around"
  },
  header: {
    fontSize: 36,
    marginBottom: 48
  },
  textInput: {
    borderColor: "white",
    borderBottomWidth: 1,
    marginBottom: 36,
    height: 270,
  },
  bottomContainer: {
    backgroundColor: "white",
    marginTop: 5
  }
});
export default KeyboardAvoidingComponent;
